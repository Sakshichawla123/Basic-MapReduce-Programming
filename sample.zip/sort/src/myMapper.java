import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class myMapper extends Mapper<myKey, myValue, Text, DoubleWritable> {
	
	public void map(myKey inpK, myValue inpV, Context c) throws IOException, InterruptedException{
	
		 
		 c.write(inpK.getamt(), new DoubleWritable(amt));
		
	  	   }
		
	}



