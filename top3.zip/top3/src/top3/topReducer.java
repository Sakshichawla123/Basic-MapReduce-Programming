package top3;

import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class topReducer extends Reducer<Text, IntWritable, Text,Text>{
	HashMap hm=new HashMap<>();
public void reduce(Text inpk, Iterable<IntWritable> inpv, Context c){
	int count=0;
	for(IntWritable line: inpv){
		count=count+line.get();
		}
	hm.put(inpk, new IntWritable(count));
}
public void cleanup(Context c)
{
	
	Map sortedMap=sortByValues(hm);
	int counter=0;
	for(Text inpk:sortedMap.keySet()){
		if(counter++==3)
		{
			break;
		}
		c.write(inpk,sortedMap.get(inpk));
	}
}
private Map sortByValues(HashMap hm2) {
	// TODO Auto-generated method stub
	return null;
}
}
