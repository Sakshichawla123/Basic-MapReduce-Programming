package top3;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class topMapper extends Mapper<LongWritable,Text,Text,IntWritable>{
	public void map(LongWritable inpK,Text inpV, Context c) throws IOException, InterruptedException{
		String value = inpV.toString() ;
		String eachval[]=value.split(" ");
		c.write(new Text(eachval[2]), new IntWritable(1));
	}
}
