package sample;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class myReducer extends Reducer<Text, IntWritable, Text, IntWritable>{
	public void reduce(Text inpK, Iterable<IntWritable> inpV, Context c) throws IOException, InterruptedException{
int count =0;
	for(IntWritable x:inpV)
		count++;
	c.write(new Text("The total number of "+inpK+"is"),new IntWritable(count));
}
}
