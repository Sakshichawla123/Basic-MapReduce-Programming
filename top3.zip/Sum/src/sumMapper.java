import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class sumMapper extends Mapper<LongWritable, Text, IntWritable, DoubleWritable>{
public void map(LongWritable inpk, Text inpv, Context c) throws IOException, InterruptedException{
	String value=inpv.toString();
	String eachval[]=value.split(",");
	Text date = new Text(eachval[1]);
	String val=date.toString();
	String dateval[]=val.split("-");
	int num = Integer.parseInt(dateval[0]);
	double num1=Double.parseDouble(eachval[3]);
	IntWritable outK = new IntWritable(num);
	DoubleWritable outV=new DoubleWritable(num1);
	c.write(outK, outV);
}
}
