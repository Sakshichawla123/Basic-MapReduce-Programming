package test;


import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class myPartitioner extends Partitioner<IntWritable, Text> {

	
	public int getPartition(IntWritable arg0, Text arg1, int arg2) {
		int mon  = arg0.get();
		if(mon==1)
				return 0;
		else if(mon==2)
			return 0;
		else if(mon==3)
			return 0;
		else if(mon==4)
			return 0;
		else if(mon==5)
			return 0;
		else if(mon==6)
			return 0;
		else if(mon==7)
			return 0;
		else if(mon==8)
			return 0;
		else if(mon==9)
			return 0;
		else if(mon==10)
			return 0;
		else if(mon==11)
			return 0;
		else if(mon==12)
			return 0;
		else 
			return 1;
	}

}
