package amount;

public class amtReducer {

}
