package amount;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class amtMapper extends Mapper<LongWritable, Text, Text, IntWritable> {
public void amtMap(LongWritable inpk, Text inpv, Context c) throws IOException, InterruptedException{
	String value=inpv.toString();
	String eachval[]=value.split(",");
	int num=Integer.parseInt(eachval[1]);
	if(num>160)
	c.write(new Text(eachval[0]), new IntWritable(num));		
}
}
