package sort;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class myMapper extends Mapper<LongWritable, Text,Text,Text>{
public void map(LongWritable key, Text value, Context c){
	
}
}
