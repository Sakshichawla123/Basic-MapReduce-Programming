import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;

public class myKey implements WritableComparable {
	DoubleWritable amt;
	
	public myKey(){
		
		this.amt = new DoubleWritable();
	}
	public myKey(DoubleWritable amt){
	
		this.amt = amt;		
	}
	@Override
	public void readFields(DataInput arg0) throws IOException {
		
		amt.readFields(arg0);		
	}

	@Override
	public void write(DataOutput arg0) throws IOException {
		
		amt.write(arg0);
	}

	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}
	public void setid(DoubleWritable amt){
		this.amt=amt;
	}
	
	
	public DoubleWritable getamt() {
		return amt;
	}
	
	
}
